/****************************************************************************
** Meta object code from reading C++ file 'registro_dialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../registro_dialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'registro_dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_registro_dialog_t {
    QByteArrayData data[13];
    char stringdata0[182];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_registro_dialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_registro_dialog_t qt_meta_stringdata_registro_dialog = {
    {
QT_MOC_LITERAL(0, 0, 15), // "registro_dialog"
QT_MOC_LITERAL(1, 16, 13), // "enviaRegistro"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 6), // "Cuenta"
QT_MOC_LITERAL(4, 38, 1), // "u"
QT_MOC_LITERAL(5, 40, 8), // "registra"
QT_MOC_LITERAL(6, 49, 18), // "enviaRevisaUsuario"
QT_MOC_LITERAL(7, 68, 10), // "recibeBool"
QT_MOC_LITERAL(8, 79, 24), // "on_correo_LE_textChanged"
QT_MOC_LITERAL(9, 104, 4), // "arg1"
QT_MOC_LITERAL(10, 109, 25), // "on_usuario_LE_textChanged"
QT_MOC_LITERAL(11, 135, 22), // "on_cont_LE_textChanged"
QT_MOC_LITERAL(12, 158, 23) // "on_registro_BB_accepted"

    },
    "registro_dialog\0enviaRegistro\0\0Cuenta\0"
    "u\0registra\0enviaRevisaUsuario\0recibeBool\0"
    "on_correo_LE_textChanged\0arg1\0"
    "on_usuario_LE_textChanged\0"
    "on_cont_LE_textChanged\0on_registro_BB_accepted"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_registro_dialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x06 /* Public */,
       5,    0,   57,    2, 0x06 /* Public */,
       6,    2,   58,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    1,   63,    2, 0x08 /* Private */,
       8,    1,   66,    2, 0x08 /* Private */,
      10,    1,   69,    2, 0x08 /* Private */,
      11,    1,   72,    2, 0x08 /* Private */,
      12,    0,   75,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    2,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,

       0        // eod
};

void registro_dialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<registro_dialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->enviaRegistro((*reinterpret_cast< Cuenta(*)>(_a[1]))); break;
        case 1: _t->registra(); break;
        case 2: _t->enviaRevisaUsuario((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 3: _t->recibeBool((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_correo_LE_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_usuario_LE_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->on_cont_LE_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->on_registro_BB_accepted(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (registro_dialog::*)(Cuenta );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&registro_dialog::enviaRegistro)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (registro_dialog::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&registro_dialog::registra)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (registro_dialog::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&registro_dialog::enviaRevisaUsuario)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject registro_dialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_registro_dialog.data,
    qt_meta_data_registro_dialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *registro_dialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *registro_dialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_registro_dialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int registro_dialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void registro_dialog::enviaRegistro(Cuenta _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void registro_dialog::registra()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void registro_dialog::enviaRevisaUsuario(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
